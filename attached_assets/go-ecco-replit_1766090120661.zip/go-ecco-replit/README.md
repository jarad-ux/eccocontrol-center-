# Go Ecco Climate Control - Field Sales Entry System

A professional web application for field sales representatives to enter and track customer sales data.

## Features

- **User Authentication** - Role-based access (Admin/Rep)
- **Sales Entry Form** - Complete customer and equipment data capture
- **Dashboard** - Real-time sales metrics and recent submissions
- **Multiple Integrations**:
  - Primary Webhook (Zapier, Make, etc.)
  - Lidy.ai for AI-powered lead processing
  - Retell AI for voice agent integrations
  - Resend for email notifications
  - Google Sheets backup

## Demo Credentials

| Username | Password | Role |
|----------|----------|------|
| admin | admin123 | System Admin |
| jmajors | goeco2024 | Admin (Joey Majors) |
| rep1 | sales123 | Sales Rep |

## Divisions

- Nevada (NV)
- Maryland (MD)
- Georgia (GA)
- Delaware (DE)

## Equipment Types

- Central Air Conditioner
- Gas Furnace
- Electric Furnace
- Heat Pump
- Mini Split / Ductless
- Package Unit
- Boiler
- Water Heater
- Dual Fuel System
- Geothermal
- Other

## Getting Started

1. Click **Run** to start the development server
2. Log in with one of the demo credentials above
3. Configure your webhooks and API keys in Settings (Admin only)

## Tech Stack

- React 18
- Vite
- CSS-in-JS styling

## Configuration

Admin users can configure the following in Settings:

- **Primary Webhook URL** - For sale submission notifications
- **Lidy.ai** - Webhook URL and API Key
- **Retell AI** - API Key and Agent ID
- **Resend** - API Key and email addresses
- **Google Sheets** - Sheet ID and tab name for backups
